#!/bin/bash
exec ./a.out
